module.exports = {
  pathPrefix: '/sidebars',
  plugins: [
    'gatsby-plugin-sass',
  ],
}
